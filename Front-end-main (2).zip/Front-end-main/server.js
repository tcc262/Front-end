const session = require('express-session');
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const bcrypt = require('bcrypt');

const app = express();

// Configuração do MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '31071906may',
    database: 'CadastroAlunos'
});

// Conectar ao banco de dados
connection.connect();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use((req, res, next) => {
    console.log(`Requisição para recurso estático: ${req.path}`);
    next();
});
app.use((req, res, next) => {
    console.log(`Recebendo solicitação: ${req.method} ${req.path}`);
    console.log('Body:', req.body);
    next();
});

app.use(express.static(__dirname));
app.use(session({
    secret: 'seu_segredo_aqui',  // Escolha um valor secreto para assinar o ID da sessão.
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }  // Defina como true se estiver usando HTTPS
  }));
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.get('/entrar.html', (req, res) => {
    res.sendFile(__dirname + '/Front-end-main/entrar.html');
});

app.use(bodyParser.json());
// Rota para processar o cadastro de alunos
app.post('/processar_cadastro', (req, res) => {
    const { nome, curso, periodo, matricula, email, senha } = req.body;

    console.log("Dados recebidos:", req.body);  // Log dos dados recebidos
    console.log("Senha recebida:", senha);  // Log da senha

    if (!senha) {
        console.error("Senha não fornecida ou indefinida");
        res.send("Erro ao cadastrar. Senha não fornecida.");
        return;
    }

    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(senha, salt);

    const query = 'INSERT INTO Alunos (nome, curso, periodo, matricula, email, senha) VALUES (?, ?, ?, ?, ?, ?)';
    connection.query(query, [nome, curso, periodo, matricula, email, hashedPassword], (err, results) => {
        if (err) {
            console.error("Erro ao inserir os dados:", err);
            res.send("Erro ao cadastrar. Tente novamente.");
        } else {
            res.sendFile(__dirname + '/entrar.html');
        }
    });
});

// Rota para processar o cadastro de monitores
app.post('/processar_cadastro_monitor', (req, res) => {
    const { nome, curso, periodo, materia_da_monitoria, matricula, email, senha } = req.body;
    console.log(senha);
    console.log("Dados recebidos:", req.body);  // Log dos dados recebidos
    console.log("Senha recebida:", senha);  // Log da senha

    if (!senha) {
        console.error("Senha não fornecida ou indefinida");
        res.send("Erro ao cadastrar. Senha não fornecida.");
        return;
    }

    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(senha, salt);

        const query = 'INSERT INTO Monitores (nome, curso, periodo, materia_da_monitoria, matricula, email, senha) VALUES (?, ?, ?, ?, ?, ?, ?)';
        connection.query(query, [nome, curso, periodo, materia_da_monitoria, matricula, email, hashedPassword], (err, results) => {
            if (err) {
                console.error("Erro ao inserir os dados:", err);
                res.send("Erro ao cadastrar. Tente novamente.");
            } else {
                res.sendFile(__dirname + '/entrar.html');
                
            }
        });
    });


// Rota para processar o login
app.post('/login', (req, res) => {
    console.log("Acessando rota /login");
    const { email, senha: password } = req.body;
    console.log(`Dados de login recebidos: Email: ${email}, Senha: ${password}`);

    const queryAluno = 'SELECT senha FROM Alunos WHERE email = ?';
    connection.query(queryAluno, [email], (err, results) => {
        if (err) {
            console.error("Erro ao buscar o email na tabela Alunos:", err);
            res.status(500).send("Erro interno do servidor");
            return;
        }

        if (results.length === 0) {
            // Se o email não for encontrado na tabela Alunos, procuramos na tabela Monitores
            const queryMonitor = 'SELECT senha FROM Monitores WHERE email = ?';
            connection.query(queryMonitor, [email], (err, results) => {
                if (err) {
                    console.error("Erro ao buscar o email na tabela Monitores:", err);
                    res.status(500).send("Erro interno do servidor");
                    return;
                }
                
                if (results.length === 0) {
                    res.status(400).send("Email não encontrado");
                    return;
                }

                verifyPassword(results, "Monitor");
            });
        } else {
            verifyPassword(results, "Aluno");
            
        }
    });

    function verifyPassword(results, userType) {
        const hashedPassword = results[0].senha;
    
        bcrypt.compare(password, hashedPassword, (err, isMatch) => {
            if (err) {
                console.error("Erro ao comparar senha:", err);
                res.status(500).send("Erro interno do servidor");
                return;
            }
    
            if (!isMatch) {
                res.status(400).send("Senha incorreta");
                return;
            }else{
                
                if (userType === "Aluno") {
                    req.session.alunoEmail = email;
                    console.log("Email do monitor na sessão:", req.session.alunoEmail);
                    res.sendFile(__dirname + '/tela_aluno.html');
                } else if (userType === "Monitor") {
                    req.session.monitorEmail = email;
                    console.log("Email do monitor na sessão:", req.session.monitorEmail);
                    res.sendFile(__dirname + '/tela_monitor.html');
                } else {
                    res.status(500).send("Erro ao determinar o tipo de usuário");
                }
            }
    
            
        });
    }
});
app.get('/perfil_monitor', (req, res) => {
    if (!req.session.monitorEmail) {
        return res.status(400).send("Monitor não autenticado");
    }

    const emailMonitor = req.session.monitorEmail;
    const query = 'SELECT * FROM Monitores WHERE email = ?';

    connection.query(query, [emailMonitor], (err, results) => {
        if (err) {
            console.error("Erro ao buscar os detalhes do monitor:", err);
            res.status(500).send("Erro interno do servidor");
            return;
        }

        if (results.length === 0) {
            res.status(400).send("Monitor não encontrado");
            return;
        }

        const monitorDetails = results[0];
        res.json(monitorDetails);
    });
});


app.get('/perfil_aluno', (req, res) => {
    if (!req.session.alunoEmail) {
        return res.status(400).send("Aluno não autenticado");
    }

    const emailAluno = req.session.alunoEmail;
    const query = 'SELECT * FROM Alunos WHERE email = ?';

    connection.query(query, [emailAluno], (err, results) => {
        if (err) {
            console.error("Erro ao buscar os detalhes do aluno:", err);
            res.status(500).send("Erro interno do servidor");
            return;
        }

        if (results.length === 0) {
            res.status(400).send("Aluno não encontrado");
            return;
        }

        const alunoDetails = results[0];
        res.json(alunoDetails);
    });
});


app.post('/atualizar_config_monitor', (req, res) => {
    const { name: nome, email, password: senha, periodo, 'materia-da-monitoria': materia_da_monitoria } = req.body;

    if (!senha || senha.trim() === "") {
        console.error("Senha não fornecida ou indefinida");
        return res.send("Erro ao atualizar. Senha não fornecida.");
    }

    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(senha, salt);

    // Criando uma query de atualização dinâmica
    let updateFields = [];
    let updateValues = [];

    if (nome) {
        updateFields.push("nome=?");
        updateValues.push(nome);
    }
    if (periodo) {
        updateFields.push("periodo=?");
        updateValues.push(periodo);
    }
    if (materia_da_monitoria) {
        updateFields.push("materia_da_monitoria=?");
        updateValues.push(materia_da_monitoria);
    }
    if (hashedPassword) {
        updateFields.push("senha=?");
        updateValues.push(hashedPassword);
    }

    updateValues.push(email);  // Adicionando o email como valor de filtragem

    const queryUpdate = `UPDATE Monitores SET ${updateFields.join(", ")} WHERE email=?`;

    connection.query(queryUpdate, updateValues, (err, results) => {
        if (err) {
            console.error("Erro ao atualizar configurações do monitor:", err);
            return res.send("Erro ao atualizar. Tente novamente.");
        }
        if (results.affectedRows === 0) {
            return res.send("Erro: Nenhum monitor encontrado com o e-mail fornecido.");
        }
        res.send("Configurações de monitor atualizadas com sucesso!");
    });
});

app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error("Erro ao realizar logout:", err);
            return res.send("Erro ao realizar logout. Tente novamente.");
        }
        res.redirect('/entrar.html');  // Redireciona para a página de login após o logout
    });
});

app.post('/atualizar_config_aluno', (req, res) => {
    console.log("Dados recebidos:", req.body);
    const { name: nome, email, password: senha } = req.body;

    if (!senha || senha.trim() === "") {
        console.error("Senha não fornecida ou indefinida");
        return res.send("Erro ao atualizar. Senha não fornecida.");
    }

    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(senha, salt);

    // Criando uma query de atualização dinâmica
    let updateFields = [];
    let updateValues = [];

    if (nome) {
        updateFields.push("nome=?");
        updateValues.push(nome);
    }
    
    if (hashedPassword) {
        updateFields.push("senha=?");
        updateValues.push(hashedPassword);
    }

    updateValues.push(email);  // Adicionando o email como valor de filtragem

    const queryUpdate = `UPDATE Alunos SET ${updateFields.join(", ")} WHERE email=?`;

    connection.query(queryUpdate, updateValues, (err, results) => {
        if (err) {
            console.error("Erro ao atualizar configurações do aluno:", err);
            return res.send("Erro ao atualizar. Tente novamente.");
        }
        if (results.affectedRows === 0) {
            return res.send("Erro: Nenhum aluno encontrado com o e-mail fornecido.");
        }
        res.send("Configurações de aluno atualizadas com sucesso!");
    });
});

app.post('/processar_recuperacao_senha', (req, res) => {
    const { email, matricula } = req.body;

    // Vamos verificar se o e-mail e a matrícula correspondem a um registro no banco de dados
    const query = 'SELECT * FROM Alunos WHERE email = ? AND matricula = ?';
    connection.query(query, [email, matricula], (err, results) => {
        if (err) {
            console.error("Erro ao buscar os detalhes do aluno:", err);
            return res.send("Erro interno do servidor. Tente novamente.");
        }

        if (results.length === 0) {
            return res.send("E-mail ou matrícula incorretos.");
        }

        // Se a correspondência for encontrada, gere uma senha temporária
        const tempPassword = Math.random().toString(36).slice(-8);
        const salt = bcrypt.genSaltSync(10);
        const hashedTempPassword = bcrypt.hashSync(tempPassword, salt);

        // Atualizar a senha no banco de dados
        const updateQuery = 'UPDATE Alunos SET senha = ? WHERE email = ? AND matricula = ?';
        connection.query(updateQuery, [hashedTempPassword, email, matricula], (err, updateResults) => {
            if (err) {
                console.error("Erro ao atualizar a senha:", err);
                return res.send("Erro interno do servidor. Tente novamente.");
            }
            res.send(`Senha temporária gerada: ${tempPassword}. Use essa senha para entrar e, em seguida, mude-a.`);
        });
    });
});

app.get('/materia_monitor', (req, res) => {
    if (!req.session.monitorEmail) {
        return res.status(400).send("Monitor não autenticado");
    }

    const emailMonitor = req.session.monitorEmail;
    const query = 'SELECT materia_da_monitoria FROM Monitores WHERE email = ?';

    connection.query(query, [emailMonitor], (err, results) => {
        if (err) {
            console.error("Erro ao buscar a matéria do monitor:", err);
            res.status(500).send("Erro interno do servidor");
            return;
        }

        if (results.length === 0) {
            res.status(400).send("Monitor não encontrado");
            return;
        }

        const materiaMonitor = results[0].materia_da_monitoria;
        res.json({ materia: materiaMonitor });
    });
});

app.listen(3000, () => {
    console.log("Servidor rodando na porta 3000");
});